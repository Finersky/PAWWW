<?php
	$nr_indeksu = '164338';
	$nrGrupy = '1ISI';

	echo 'Nikodem Banach'.$nr_indeksu.'grupa'.$nrGrupy.'<br /><br/>';

	echo 'Zastosowanie metody include() <br/>';

	echo 'Zastosowanie metody include() <br /><br />';

	echo "zadanie 2 pkt a <br/><br />";

	include 'vars.php';

	echo '<br/><br/>';

	echo "zadanie 2 pkt b <br/><br />";

	$a = '5';
	$b = '4';

	if ($a > $b)
		echo "a is bigger than b <br /><br />";

	echo "zadanie 2 pkt c <br/><br />";

	$i = 1;
	while ($i <= 10) {
		echo $i++;  
	}

 

	echo '<br/><br/>';

	for($i=10;$i>0;$i--){
		echo $i.'<br>';
	}

 

	echo '<br/><br/>';

	echo "zadanie 2 pkt d <br/><br />";

	echo 'Hello ' . htmlspecialchars($_GET["fname"]) . '!';

	echo '<br/><br/>';

	echo '<br/><br/>';

	session_start();

 

	$_SESSION["newsession"]=$value;

 

	echo $_SESSION["newsession"];

?>
<html>
<body>

 

<form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
  Name: <input type="text" name="fname">
<input type="submit">
</form>

 

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // collect value of input field
  $name = $_POST['fname'];
  if (empty($name)) {
    echo "Name is empty";
  } else {
    echo 'Hello ' . htmlspecialchars($_POST["fname"]) . '!';
  }
}
?>

 

</body>
</html>